﻿// See https://aka.ms/new-console-template for more information

//declare the variables
double w, f, s, I, n, a, b, y;

//assign their default values
w = 0.0;
f = 0.0;
s = 0.0;
I = 0.0;
n = 0.0;

//make a to represent a portion of the formula
a = ((s * I) / f) + Math.Pow(20 / f, w);

//make b to represent a portion of the formula
b = (Math.Pow(f, n) * a) / Math.Pow(20, n);

y = I - b;

Console.WriteLine(y);

