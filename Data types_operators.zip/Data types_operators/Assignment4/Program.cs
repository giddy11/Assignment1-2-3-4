﻿// See https://aka.ms/new-console-template for more information

//Edoghotu Gideon

int a = 10;
int b = 20;
int c = 30;

bool isTrue1 = (a == b);
bool isTrue2 = (c > (a + b - c));
bool isTrue3 = (c - b == a);

bool answer = (isTrue1 && isTrue2 && isTrue3) ? true : false;

Console.WriteLine(answer);


